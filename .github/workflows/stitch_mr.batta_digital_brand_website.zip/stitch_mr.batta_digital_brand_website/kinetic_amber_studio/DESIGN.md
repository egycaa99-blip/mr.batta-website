---
name: Kinetic Amber Studio
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#d8c3ad'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#a08e7a'
  outline-variant: '#534434'
  surface-tint: '#ffb95f'
  primary: '#ffc174'
  on-primary: '#472a00'
  primary-container: '#f59e0b'
  on-primary-container: '#613b00'
  inverse-primary: '#855300'
  secondary: '#ffc640'
  on-secondary: '#402d00'
  secondary-container: '#e3aa00'
  on-secondary-container: '#5a4100'
  tertiary: '#d7cda3'
  on-tertiary: '#363113'
  tertiary-container: '#bab189'
  on-tertiary-container: '#4a4424'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffddb8'
  primary-fixed-dim: '#ffb95f'
  on-primary-fixed: '#2a1700'
  on-primary-fixed-variant: '#653e00'
  secondary-fixed: '#ffdf9f'
  secondary-fixed-dim: '#f9bd22'
  on-secondary-fixed: '#261a00'
  on-secondary-fixed-variant: '#5c4300'
  tertiary-fixed: '#ede3b8'
  tertiary-fixed-dim: '#d1c79d'
  on-tertiary-fixed: '#201c02'
  on-tertiary-fixed-variant: '#4d4727'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-xl:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
  display-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses a high-caliber digital media network fused with the magnetic charm and irreverent wit of premier Egyptian digital storytelling. It sits at the intersection of a cutting-edge video streaming platform, high-energy documentary journalism (à la Vox or Vice), and the pulse of contemporary creator culture. 

The aesthetic is cinematic, immersive, and dark-mode native. It utilizes rich obsidian and slate foundations punctuated by electric golden ambers that mimic studio key-lights and sunlit Cairo streetscapes. The visual language balances premium media authority with direct, punchy audience engagement. Visual elements lean into high-contrast interfaces, layered translucent glass surfaces, dynamic telemetry counters, and high-impact editorial framing.

## Colors

The palette operates with a cinematic, low-key lighting approach. Dark obsidian surfaces reduce eye fatigue and make 16:9 video content pop, while saturated golden ambers deliver immediate focus on interactive touchpoints, live pulses, and calls to action.

- **Primary Amber (`#F59E0B`)**: High-energy hero accent. Used for primary interactions, featured video highlights, active state badges, and verified creator accolades.
- **Secondary Sunburst (`#FBBF24`)**: Brighter yellow-gold tier. Reserved for hover states, glowing highlights, micro-badges, and live notification rings.
- **Warm Cream Accent (`#FEF3C7`)**: High-legibility tertiary tone for subheadings, quotes, subtle pill borders, and high-contrast badges against dark backgrounds.
- **Neutral Obsidian (`#0F172A`)**: Base canvas tone. Anchors the media experience in theatrical darkness.
- **Surface Slate (`#1E293B`)**: Raised surface container for cards, panels, bottom sheets, and navigation bars.
- **Muted Slate (`#64748B`)**: Secondary metadata, timecodes, view counts, and inactive controls.

## Typography

The type system blends the structured geometry of **Space Grotesk** with the balanced warmth and multi-script legibility of **Plus Jakarta Sans**. 

- **Display & Headlines (`Space Grotesk`)**: Technical yet expressive, lending authority and contemporary creator energy to video titles, episode numbering, and high-impact impact statements. Letter-spacing on display tokens is slightly compressed (-0.02em) to maintain editorial density.
- **Body & Captions (`Plus Jakarta Sans`)**: Neutral, open, and friendly. Maintains exceptional reading cadence across both long-form editorial journalism and short-form video descriptions. Naturally harmonizes with modern Arabic typefaces such as Cairo for bilingual deployments.
- **Labels & Micro-data**: Rendered in uppercase or bold tracking for timecodes, category tags, and viewer statistics.

## Layout & Spacing

The layout is built upon a 12-column responsive fluid grid designed specifically for video-first media feeds, documentary dossiers, and creator drops.

- **Desktop (1200px+)**: 12 columns, 24px gutters, max-width 1440px canvas. Enables asymmetric magazine grids (8-column lead video player with 4-column live chat or interactive sidebar).
- **Tablet (768px - 1199px)**: 8 columns, 20px gutters. Horizontal rail carousels for related episodes and series tracks.
- **Mobile (< 768px)**: 4 columns, 16px gutters with edge-to-edge video bleed capabilities. Vertical content stack prioritizing full-bleed 9:16 shorts, dynamic thumbnails, and quick-action toolbars.

Spacing rhythm prioritizes tight relationships between media previews and metadata (`space-xs` to `space-sm`), standard interior card padding (`space-md`), and distinct section demarcations (`space-xl` to double `space-xl`).

## Elevation & Depth

Visual hierarchy uses layered dark surfaces combined with selective frosted glass and warm ambient key-lights.

- **Level 0 (Canvas Base)**: Pure `#0F172A`. Deep background for the main viewport.
- **Level 1 (Card & Content Surface)**: Solid `#1E293B` or semi-opaque glass (`rgba(30, 41, 59, 0.75)` with `16px` backdrop-blur). Used for media cards, episode modules, and comment threads. Borders feature a crisp, low-contrast ghost outline (`rgba(255, 255, 255, 0.08)`).
- **Level 2 (Hover & Focus States)**: Surface transitions with an energetic amber-tinted ambient glow: `0 8px 24px -4px rgba(245, 158, 11, 0.15)`.
- **Level 3 (Floating Controls & Modals)**: Dark obsidian glass (`rgba(15, 23, 42, 0.88)` with `24px` blur), topped with a razor-thin top-lit highlight (`border-t: 1px solid rgba(251, 191, 36, 0.25)`) and deep shadow `0 20px 40px -8px rgba(0, 0, 0, 0.6)`.

## Shapes

The design system incorporates a modern, balanced curvature (`roundedness: 2`, where base elements sit at `0.5rem / 8px`). This provides an approachable, contemporary feel without drifting into juvenile softness.

- **Micro Controls & Tags**: 6px (`rounded-sm`) to 8px (`rounded-md`).
- **Media Cards & Player Containers**: 16px (`rounded-lg`) to preserve crisp 16:9 and 9:16 corner definition.
- **Badges, Status Chips, and Action Pills**: Fully rounded pill shapes (`9999px`) to emphasize community status, live feeds, and category navigation.

## Components

### Buttons & Interactive Triggers
- **Primary CTA**: Solid Amber (`#F59E0B`) with dark obsidian text (`#0F172A`, font-weight 700). On hover, steps up to Sunburst (`#FBBF24`) with an ambient gold glow.
- **Secondary Ghost**: Transparent background with 1px border (`rgba(254, 243, 197, 0.2)`), warm cream text (`#FEF3C7`), shifting to `rgba(245, 158, 11, 0.1)` on interaction.
- **Play Buttons**: Circular floating action triggers with blurred glass backdrop, amber accent icon, and subtle scale-up animation on pointer enter.

### Chips & Micro-Badges
- **Status Pills (Live / Exclusive)**: High-visibility amber-yellow text on `rgba(245, 158, 11, 0.15)` background with a pulsating 6px dot indicator.
- **Category Filter Chips**: Dark slate surface (`#1E293B`) with white-muted typography, snapping to solid amber fill with dark typography when active.

### Media & Video Cards
- **Video Tiles**: 16:9 ratio container with 16px rounded corners, subtle low-opacity outer ring, overlay timecode badge in bottom-right corner, and dynamic thumbnail zoom on hover.
- **Creator Insight Cards**: Translucent glass slate surfaces housing telemetry metrics (e.g., subscriber counters, view milestones) using `Space Grotesk` display numerals paired with micro-labels.

### Form Inputs & Search
- **Search & Input Bars**: Minimalist dark slate troughs with inset shadow, featuring ghost borders (`rgba(255, 255, 255, 0.1)`). On focus, borders transition smoothly to Primary Amber with a 2px outer aura (`rgba(245, 158, 11, 0.2)`). Text displays in high-contrast neutral light.

### Community & Metric Widgets
- **Polls & Reaction Bars**: Embedded inline cards with percentage completion fills displayed in semi-translucent gold, accompanied by expressive reaction icons and micro-counter tallies.